function setNewSong(){
    dataDisplay=document.getElementById("songTitleDisplay")
    input=fetchTextBoxData()
    dataDisplay.textContent="Song: "+input
    alarmAPI('SNS',input)
};

function setNewTime(){
    dataDisplay=document.getElementById("songTimeDisplay")
    input=fetchTextBoxData()
    dataDisplay.textContent="Time: "+input
    alarmAPI('SNT',input)
};

function fetchTextBoxData(){
    let target = document.getElementById("AlarmTextInput");
    let serchPhrase = target.value;
    target.value=""
    return serchPhrase;
};

function alarmAPI(tag,data){
    const options = {
        method: 'POST',
        body: [tag,data],
        headers:{
            'Content-Type':'application/json'
        }
        };
        fetch('/alarmAPI',options);
    };

    function toggleAlarmButton(){
        let target=document.getElementById("toggleAlarmButton")
        if (target.style.backgroundColor=='red'){
          target.style.backgroundColor='lime'
          alarmAPI('TAP','T')
        }else if(target.style.backgroundColor=='lime'){
          target.style.backgroundColor='red';
          alarmAPI('TAP','F')
        }else{
          target.style.backgroundColor='lime'
          alarmAPI('TAP','T')
        }

      };