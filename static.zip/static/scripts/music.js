function fetchSerchPhrase(){
    let target = document.getElementById("musicTextInput");
    let serchPhrase = target.value;
    target.value=""
    return serchPhrase;
};

function musicApi(tag,data){
  for(let i=0; i<=tag.length; i++){
      const options = {
        method: 'POST',
        body: [tag[i],data],
        headers:{
          'Content-Type':'application/json'
        }
      };
      if(tag[i]=='FT'){
      fetch('/musicApi',options)
      .then(response => response.json())
      .then(data => setImage(data));
      }else{
      fetch('/musicApi',options)
    };
  };
};
    


function setImage(link){
    let target=document.getElementById("videoThumbNail")
    target.src=link
};

function toggleLoopButtonColor(){
  let target=document.getElementById("loopButton")
  if (target.style.backgroundColor=='red'){
    target.style.backgroundColor='lime'
  }else if(target.style.backgroundColor=='lime'){
    target.style.backgroundColor='red';
  }else{
    target.style.backgroundColor='lime'
  }
};

function toggleShuffleButtonColor(){
  let target=document.getElementById("shuffleButton")
  if (target.style.backgroundColor=='red'){
    target.style.backgroundColor='lime'
  }else if(target.style.backgroundColor=='lime'){
    target.style.backgroundColor='red';
  }else{
    target.style.backgroundColor='lime'
  }
};