

function changeIframe(target){
  var url = target;
  var element = document.getElementById('dynamicIframe')
  element.src = url
}
  
