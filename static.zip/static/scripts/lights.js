function retrieveColourValue(){
    let target = document.getElementById("colourPicker");
    let colour = target.value;
    return colour;
}

function bulbApiActuator(tag,color){
    const options = {
      method: 'POST',
      body: [tag,color],
      headers:{
        'Content-Type':'application/json'
      }
    };
    fetch('/bulbapi',options);
  }

function fetchSavedColours(){
  fetch('/bulbapi/colors')
  .then(response => response.json())
  .then(data => renderLoadPage(data));
}

function renderLoadPage(options){
    for(let i = 0; i<options.length; i++){
      const btn = document.createElement("button");
      btn.onclick=selectLoadedColor(i);
      btn.style.backgroundColor="rgb("+determineColor(options[i])+")";
      const element = document.getElementById("loadPage");
      element.appendChild(btn);
    }
      const btn = document.createElement("button");
      btn.innerHTML = 'X'
      btn.onclick=closeLodePage
      const element = document.getElementById("loadPage");
      element.appendChild(btn);
    }
    
  
  

function closeLodePage(){
  var node = document.getElementById('loadPage')
  node.innerHTML=''
}

function determineColor(array){
  return(array.toString())
}

function selectLoadedColor(num){
  return function(){
    const options = {
      method: 'POST',
      body: num,
      headers:{
        'Content-Type':'application/json'
      }
    };
    fetch('/bulbapi/colors',options);
  }
}

